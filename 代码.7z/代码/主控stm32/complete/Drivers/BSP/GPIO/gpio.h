#ifndef GPIO_H
#define GPIO_H

#include "./SYSTEM/sys/sys.h"

typedef enum{
	GPIO_A,
	GPIO_B,
	GPIO_C,
	GPIO_D
}gpio_port_enum;

typedef enum{
  pin0=((uint16_t)0x0001),
	pin1=((uint16_t)0x0002),
	pin2=((uint16_t)0x0004),
	pin3=((uint16_t)0x0008),
	pin4=((uint16_t)0x0010),
	pin5=((uint16_t)0x0020),
	pin6=((uint16_t)0x0040),
	pin7=((uint16_t)0x0080),
	pin8=((uint16_t)0x0100),
	pin9=((uint16_t)0x0200),
	pin10=((uint16_t)0x0400),
	pin11=((uint16_t)0x0800),
	pin12=((uint16_t)0x1000),
	pin13=((uint16_t)0x2000),
	pin14=((uint16_t)0x4000),
	pin15=((uint16_t)0x8000),
	pin_all=((uint16_t)0xFFFF)
}gpio_pin_enum;

/**
* @brief gpioa������ų�ʼ��
*
* @note Ĭ�ϵ�ģʽΪ������� GPIO_MODE_OUTPUT_PP
*
* @param pin�����ţ� dat�ǳ�ʼ�����ŵĵ�ƽ�ߵͣ�0Ϊlow��1Ϊhigh
**/
void gpio_init (gpio_port_enum port,gpio_pin_enum pin, uint8_t dat);
void gpio_init_output_od (gpio_port_enum port,gpio_pin_enum pin, uint8_t dat);
void gpio_set_level (gpio_port_enum port,gpio_pin_enum pin,GPIO_PinState dat);

#endif
