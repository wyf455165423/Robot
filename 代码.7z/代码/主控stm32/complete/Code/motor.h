#ifndef MOTOR_H
#define MOTOR_H

#include "timer.h"
#include "gpio.h"

typedef enum{
			MOTOR_L,
			MOTOR_R
}motor_enum;

#define DIR_R   pin11 
#define DIR_L   pin5

typedef struct motor_param_t{
        int total_encoder;
        int encoder_raw;
        float encoder_speed;
        float target_speed;
        float duty;        
}motor_param_t;

extern motor_param_t motor_r,motor_l;
void set_motor_pwm(motor_enum motor_type, uint16_t duty);
void init_dual_motor_pwm(void);

#endif
