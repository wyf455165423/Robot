#ifndef ENCODER_DIR_H
#define ENCODER_DIR_H

#include "timer.h"
#include "motor.h"


int16_t Get_Left_encoder(void);
int16_t Get_Right_encoder(void);
void Encoder_Get_Date(void);

#endif
