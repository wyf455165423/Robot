#include "Encoder_dir.h"

int16_t Get_Left_encoder(){
	 return (int16_t)(__HAL_TIM_GET_COUNTER(&htim3));
}

int16_t Get_Right_encoder(){
	 return (int16_t)(__HAL_TIM_GET_COUNTER(&htim5));
}

float low_filter=0.3;
void Encoder_Get_Date(void){
	  motor_l.encoder_raw=Get_Left_encoder();
		motor_l.encoder_speed=motor_l.encoder_speed*low_filter+motor_l.encoder_raw*(1-low_filter);
		motor_l.total_encoder+=motor_l.encoder_raw;
		__HAL_TIM_SET_COUNTER(&htim3,0);
		
    motor_r.encoder_raw=Get_Right_encoder();
		motor_r.encoder_speed=motor_r.encoder_speed*low_filter+motor_r.encoder_raw*(1-low_filter);
		motor_r.total_encoder+=motor_r.encoder_raw;	
		__HAL_TIM_SET_COUNTER(&htim5,0);
}
