#ifndef PID_H
#define PID_H

#include "Encoder_dir.h"
#include "motor.h"

void CascadePID_Init(CascadePID *pid, float sample_time_ms);
void motor_pid_init(void);
void motor_contral(void);

extern float LPWM,RPWM;
#endif