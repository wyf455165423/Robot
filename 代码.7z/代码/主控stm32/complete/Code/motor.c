#include "motor.h"
#include "UART1.h"
#include "pid.h"
motor_param_t motor_r={0,0,0,0,0};
motor_param_t motor_l={0,0,0,0,0};


//���Ƶ��17000HZ
void init_dual_motor_pwm(void)
{
    uint16_t arr = 100;
    uint16_t psc = 42;

    motor_pwm_init(&motorl_tim_pwm_handle, TIM_CHANNEL_3, arr, psc);
    motor_pwm_init(&motor2_tim_pwm_handle, TIM_CHANNEL_4, arr, psc);
		
		gpio_init(GPIO_C,DIR_R, 1);
		gpio_init(GPIO_A,DIR_L, 1);
}

void set_motor_pwm(motor_enum motor_type, uint16_t duty)
{
		switch(motor_type)
		{
			case MOTOR_L: 	__HAL_TIM_SET_COMPARE(&motorl_tim_pwm_handle,TIM_CHANNEL_3,duty); //HAL�����üĴ���CCR
										break;
			
			case MOTOR_R: 	__HAL_TIM_SET_COMPARE(&motor2_tim_pwm_handle,TIM_CHANNEL_4,duty);; 
										break;
		}
}

void Motion_Send_Data(void)
{
  #define MotionLEN        7
  uint8_t data_buffer[MotionLEN] = {0};
  uint8_t i, checknum = 0;
  
  if (left_speed_mm_s < 0) {
    data_buffer[0] = 0x00;
    uint16_t spd = (uint16_t)fabs(Lpwm);
    data_buffer[1] = spd&0xFF;
    data_buffer[2] = (spd>>8)&0xFF;
  } else {
    data_buffer[0] = 0xFF;
    uint16_t spd = (uint16_t)Lpwm;
    data_buffer[1] = spd&0xFF;
    data_buffer[2] = (spd>>8)&0xFF;
  }

  if (right_speed_mm_s < 0) {
    data_buffer[3] = 0x00;
    uint16_t spd = (uint16_t)fabs(Rpwm);
    data_buffer[4] = spd&0xFF;
    data_buffer[5] = (spd>>8)&0xFF;
  } else {
    data_buffer[3] = 0xFF;
    uint16_t spd = (uint16_t)Rpwm;
    data_buffer[4] = spd&0xFF;
    data_buffer[5] = (spd>>8)&0xFF;
  }

  for (i = 0; i < MotionLEN - 1; i++)
    checknum += data_buffer[i];

  data_buffer[MotionLEN - 1] = checknum & 0xFF;
  UART1_Put_Char(0x55);
  UART1_Put_Char(0x02);
  UART1_Put_Char(0x06); 
  
  UART1_Put_Char(data_buffer[0]);
  UART1_Put_Char(data_buffer[1]);
  UART1_Put_Char(data_buffer[2]);
  UART1_Put_Char(data_buffer[3]);
  UART1_Put_Char(data_buffer[4]);
  UART1_Put_Char(data_buffer[5]);
  UART1_Put_Char(data_buffer[6]);
  
  UART1_Put_Char(0xBB); // ֡β
}

/*
		uint8_t  		key;
		uint16_t 		motorl_duty=20;
		uint16_t 		motorr_duty=20;

			 key=key_scan(0);
			  if (key)
        {
            switch (key)
            {
                case WKUP_PRES:          
								{
									motorl_duty+=10;
									motorr_duty+=10;
								}
                    break;

                case KEY1_PRES:          
                {
									motorl_duty-=10;
								}    
                    break;

                case KEY0_PRES:          
                {
									motorr_duty-=10;
								}
								break;
            } 
        }
        else
        {
            delay_ms(10);
        }
			set_motor_pwm(MOTOR_L,motorl_duty);
			set_motor_pwm(MOTOR_R,motorr_duty);
				*/

