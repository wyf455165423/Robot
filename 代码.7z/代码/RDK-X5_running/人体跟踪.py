import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist, Point
from std_msgs.msg import String, Bool
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import cv2
import numpy as np
import math
import time
from enum import Enum
from threading import Lock, Thread
from queue import Queue
from dataclasses import dataclass
from typing import List, Optional, Tuple
import torch
from datetime import datetime
import json

class TrackingStatus(Enum):
    INITING = 0
    TRACKING = 1
    LOST = 2
    EMERGENCY = 3

class MovementType(Enum):
    STOP = 0
    FORWARD = 1
    BACKWARD = 2
    ROTATE_LEFT = 3
    ROTATE_RIGHT = 4

@dataclass
class PersonInfo:
    id: int
    bbox: List[int]
    keypoints: List[float]
    confidence: float
    tracking_history: List[Tuple[float, float]]
    last_update_time: float

@dataclass
class TrackInfo:
    tracking_sta: TrackingStatus = TrackingStatus.INITING
    track_id: int = -1
    present_rect: List[int] = None
    last_rect: List[int] = None
    frame_ts: int = 0
    frame_ts_sec: int = 0
    frame_ts_nanosec: int = 0
    has_face_head: bool = False
    serial_lost_num: int = 0
    serial_lost_face_head_num: int = 0
    angel_with_robot: float = 0
    move_direction: int = 0
    move_step: float = 0
    gesture: int = 0
    is_movectrl_running: bool = False
    person_info: Optional[PersonInfo] = None

class ElderlyTrackingNode(Node):
    def __init__(self):
        super().__init__('elderly_tracking_node')
        self.setup_basic_parameters()
        self.initialize_components()
        self.create_publishers_and_subscribers()
        self.initialize_tracking_system()
        self.start_monitoring_threads()

    def setup_basic_parameters(self):
        """���û�������"""
        self.img_width = 640
        self.img_height = 480
        self.fps = 30
        self.bridge = CvBridge()
        
        # ��������
        self.track_cfg = {
            'img_width': self.img_width,
            'img_height': self.img_height,
            'track_body': True,
            'activate_robot_rotate_thr': 15,
            'track_serial_lost_num_thr': 30,
            'stop_robot_move_to_top_thr': 50,
            'stop_move_rect_width_ratio_thr': 0.8,
            'start_move_rect_width_ratio_thr': 0.3,
            'move_step': 0.3,
            'rotate_step': 0.3,
            'min_detection_confidence': 0.5,
            'max_tracking_distance': 100,
        }
        
        # PID���Ʋ���
        self.pid_params = {
            'Kp': 0.5,
            'Ki': 0.1,
            'Kd': 0.2,
            'max_integral': 1.0,
            'min_integral': -1.0
        }

    def initialize_components(self):
        """��ʼ�����"""
        # ����ģ��
        self.load_models()
        
        # ��ʼ�����ݽṹ
        self.track_info = TrackInfo()
        self.person_database = {}
        self.frame_buffer = Queue(maxsize=30)
        self.emergency_queue = Queue()
        
        # ������
        self.track_lock = Lock()
        self.frame_lock = Lock()

    def load_models(self):
        """�������ѧϰģ��"""
        try:
            # ����YOLOv5ģ��
            self.yolo_model = torch.hub.load('ultralytics/yolov5', 'yolov5s')
            self.yolo_model.conf = 0.5
            
            # ����OpenPoseģ��
            self.pose_model = cv2.dnn.readNetFromCaffe(
                'pose_deploy.prototxt',
                'pose_iter_584000.caffemodel'
            )
        except Exception as e:
            self.get_logger().error(f"Model loading failed: {str(e)}")
            raise

    def create_publishers_and_subscribers(self):
        """�����������Ͷ�����"""
        # ������
        self.cmd_vel_pub = self.create_publisher(Twist, 'cmd_vel', 10)
        self.emergency_pub = self.create_publisher(String, 'emergency_alert', 10)
        self.status_pub = self.create_publisher(String, 'tracking_status', 10)
        self.pose_pub = self.create_publisher(String, 'human_pose', 10)
        
        # ������
        self.image_sub = self.create_subscription(
            Image, 
            'camera/image_raw', 
            self.image_callback, 
            10
        )
        self.emergency_stop_sub = self.create_subscription(
            Bool,
            'emergency_stop',
            self.emergency_stop_callback,
            10
        )

    def initialize_tracking_system(self):
        """��ʼ������ϵͳ"""
        self.pid_controller = {
            'last_error': 0,
            'integral': 0,
            'last_time': time.time()
        }
        
        self.tracking_metrics = {
            'last_detection_time': time.time(),
            'last_movement_time': time.time(),
            'continuous_static_time': 0,
            'fall_detection_counter': 0
        }

    def start_monitoring_threads(self):
        """��������߳�"""
        self.status_thread = Thread(target=self.status_monitoring_loop)
        self.status_thread.daemon = True
        self.status_thread.start()
        
        # ������������߳�
        self.emergency_thread = Thread(target=self.emergency_handling_loop)
        self.emergency_thread.daemon = True
        self.emergency_thread.start()

    def image_callback(self, msg):
        """����ͼ��ص�"""
        try:
            with self.frame_lock:
                cv_image = self.bridge.imgmsg_to_cv2(msg, "bgr8")
                processed_image = self.preprocess_image(cv_image)                
                detections = self.detect_people(processed_image)
                
                # ���������
                if detections:
                    self.process_detections(detections)
                    self.update_tracking_status()
                    self.check_elderly_status()
                else:
                    self.handle_lost_tracking()
                
                self.update_visualization(cv_image, detections)
                
        except Exception as e:
            self.get_logger().error(f"Error in image callback: {str(e)}")

    def preprocess_image(self, image):
        """ͼ��Ԥ����"""
        resized = cv2.resize(image, (self.img_width, self.img_height))        
        enhanced = cv2.convertScaleAbs(resized, alpha=1.2, beta=10)
        denoised = cv2.fastNlMeansDenoisingColored(enhanced)
        
        return denoised

    def detect_people(self, image):
        """ʹ��YOLOv5�������"""
        results = self.yolo_model(image)
        
        people_detections = []
        for detection in results.xyxy[0]:
            if detection[5] == 0:  
                bbox = detection[:4].tolist()
                conf = detection[4].item()
                if conf > self.track_cfg['min_detection_confidence']:
                    people_detections.append((bbox, conf))
        
        return people_detections

    def process_detections(self, detections):
        """���������"""
        with self.track_lock:
            if not detections:
                self.track_info.serial_lost_num += 1
                return
            best_detection = max(detections, key=lambda x: x[1])
            bbox, conf = best_detection
            self.track_info.last_rect = self.track_info.present_rect
            self.track_info.present_rect = bbox
            self.track_info.serial_lost_num = 0
            self.update_movement_control()

    def update_movement_control(self):
        """�����˶�����"""
        target_center_x = (self.track_info.present_rect[0] + self.track_info.present_rect[2]) / 2
        error = target_center_x - self.img_width / 2
        # PID���Ƽ���
        current_time = time.time()
        dt = current_time - self.pid_controller['last_time']
        p_term = self.pid_params['Kp'] * error
        self.pid_controller['integral'] += error * dt
        self.pid_controller['integral'] = np.clip(
            self.pid_controller['integral'],
            self.pid_params['min_integral'],
            self.pid_params['max_integral']
        )
        i_term = self.pid_params['Ki'] * self.pid_controller['integral']
        d_term = self.pid_params['Kd'] * (error - self.pid_controller['last_error']) / dt
        control_signal = p_term + i_term + d_term
        self.pid_controller['last_error'] = error
        self.pid_controller['last_time'] = current_time
        self.send_movement_command(control_signal)

    def send_movement_command(self, control_signal):
        """�����˶���������"""
        twist = Twist()
        twist.angular.z = -np.clip(control_signal, -0.5, 0.5)
        if self.track_info.present_rect:
            target_height = self.track_info.present_rect[3] - self.track_info.present_rect[1]
            desired_height = self.img_height * 0.4
            
            height_error = target_height - desired_height
            linear_speed = np.clip(-height_error * 0.01, -0.5, 0.5)
            
            twist.linear.x = linear_speed
        
        self.cmd_vel_pub.publish(twist)

    def check_elderly_status(self):
        """�������״̬"""
        current_time = time.time()
        if self.detect_movement():
            self.tracking_metrics['last_movement_time'] = current_time
            self.tracking_metrics['continuous_static_time'] = 0
        else:
            static_duration = current_time - self.tracking_metrics['last_movement_time']
            self.tracking_metrics['continuous_static_time'] = static_duration
            
            if static_duration > 30:
                self.handle_emergency("Elderly person has been static for too long")
        if self.detect_falling():
            self.tracking_metrics['fall_detection_counter'] += 1
            if self.tracking_metrics['fall_detection_counter'] > 5: 
                self.handle_emergency("Fall detected!")
        else:
            self.tracking_metrics['fall_detection_counter'] = 0

    def handle_emergency(self, message):
        """�����������"""
        emergency_data = {
            'timestamp': datetime.now().isoformat(),
            'message': message,
            'location': self.get_current_location(),
            'image': self.get_current_frame_base64()
        }
        self.emergency_queue.put(emergency_data)
        self.track_info.tracking_sta = TrackingStatus.EMERGENCY
        self.stop_robot()

    def emergency_handling_loop(self):
        """�����������ѭ��"""
        while rclpy.ok():
            if not self.emergency_queue.empty():
                emergency_data = self.emergency_queue.get()                
                # ��������
                alert_msg = String()
                alert_msg.data = json.dumps(emergency_data)
                self.emergency_pub.publish(alert_msg)               
                # ��¼��־
                self.get_logger().warn(f"Emergency: {emergency_data['message']}")
                
            time.sleep(0.1)

    def status_monitoring_loop(self):
        """״̬���ѭ��"""
        while rclpy.ok():
            current_time = time.time()
            status_msg = String()
            status_msg.data = json.dumps({
                'tracking_status': self.track_info.tracking_sta.name,
                'target_id': self.track_info.track_id,
                'continuous_static_time': self.tracking_metrics['continuous_static_time'],
                'last_update': current_time
            })
            self.status_pub.publish(status_msg)
            
            time.sleep(1.0)

def main(args=None):
    rclpy.init(args=args)
    node = ElderlyTrackingNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
