import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import cv2
import mediapipe as mp
import numpy as np
from std_msgs.msg import String
import time
from enum import Enum
import threading
from collections import deque
import os
import json

class GestureType(Enum):
    UNKNOWN = 0
    NUMBER_NINE = 1
    HELP = 2
    OK = 3
    THUMBS_UP = 4
    THUMBS_DOWN = 5

class DetectionStatus(Enum):
    NO_HAND = 0
    HAND_DETECTED = 1
    GESTURE_RECOGNIZED = 2
    EMERGENCY_TRIGGERED = 3

class GestureRecognitionNode(Node):
    def __init__(self):
        super().__init__('gesture_recognition_node')
        
        # ��ʼ������
        self.setup_parameters()
        
        self.initialize_mediapipe()
        
        self.setup_ros_communication()
        
        self.initialize_gesture_system()
        
        self.start_monitoring_thread()
        
        self.get_logger().info('Gesture Recognition Node initialized')

    def setup_parameters(self):
        """�������в���"""
        self.detection_confidence = 0.7
        self.tracking_confidence = 0.5
        self.max_hands = 2
        self.emergency_gesture_count = 5  # ��Ҫ����ʶ�𵽵Ĵ����Ŵ����������
        self.debug_mode = True
        
        self.frame_width = 640
        self.frame_height = 480
        self.fps = 30
        
        self.bridge = CvBridge()
        self.last_detection_time = time.time()
        self.gesture_counts = {gesture: 0 for gesture in GestureType}
        self.current_status = DetectionStatus.NO_HAND
        self.recent_gestures = deque(maxlen=10)  # �洢���10��ʶ����

    def initialize_mediapipe(self):
        """��ʼ��MediaPipeģ��"""
        self.mp_hands = mp.solutions.hands
        self.hands = self.mp_hands.Hands(
            static_image_mode=False,
            max_num_hands=self.max_hands,
            min_detection_confidence=self.detection_confidence,
            min_tracking_confidence=self.tracking_confidence
        )
        self.mp_draw = mp.solutions.drawing_utils
        
        self.drawing_spec = self.mp_draw.DrawingSpec(
            color=(0, 255, 0),
            thickness=2,
            circle_radius=2
        )

    def setup_ros_communication(self):
        """����ROSͨ�����"""
        self.subscription = self.create_subscription(
            Image,
            '/camera/image_raw',
            self.image_callback,
            10
        )
        
        self.emergency_publisher = self.create_publisher(
            String,
            '/emergency_alert',   # ������Ȼ���
            10
        )
        
        self.status_publisher = self.create_publisher(
            String,
            '/gesture_status',
            10
        )
        
        self.debug_image_publisher = self.create_publisher(
            Image,
            '/gesture_debug_image',
            10
        )

    def initialize_gesture_system(self):
        """��ʼ������ʶ��ϵͳ"""
        # ����ʶ����ֵ
        self.gesture_thresholds = {
            'finger_bent_threshold': 0.1,  # �ж���ָ��������ֵ
            'finger_straight_threshold': -0.1  # �ж���ָ��ֱ����ֵ
        }
        
        # ������ʷ��¼
        self.gesture_history = []
        self.last_emergency_time = 0
        self.emergency_cooldown = 10  

    def start_monitoring_thread(self):
        """��������߳�"""
        self.running = True
        self.monitor_thread = threading.Thread(target=self.monitoring_loop)
        self.monitor_thread.daemon = True
        self.monitor_thread.start()

    def monitoring_loop(self):
        """���ѭ�������ڷ���״̬��Ϣ"""
        while self.running:
            # ������ǰ״̬
            self.publish_status()
            time.sleep(1.0)

    def publish_status(self):
        """����ϵͳ״̬��Ϣ"""
        status_msg = String()
        status_data = {
            'status': self.current_status.name,
            'last_detection_time': self.last_detection_time,
            'recent_gestures': [g.name for g in list(self.recent_gestures)],
            'emergency_count': self.gesture_counts[GestureType.NUMBER_NINE]
        }
        status_msg.data = json.dumps(status_data)
        self.status_publisher.publish(status_msg)

    def image_callback(self, msg):
        """����ͼ��ص�"""
        try:
            cv_image = self.bridge.imgmsg_to_cv2(msg, "bgr8")
            
            cv_image = cv2.resize(cv_image, (self.frame_width, self.frame_height))
            
            image_rgb = cv2.cvtColor(cv_image, cv2.COLOR_BGR2RGB)
            
            results = self.hands.process(image_rgb)
            
            if results.multi_hand_landmarks:
                self.current_status = DetectionStatus.HAND_DETECTED
                self.last_detection_time = time.time()
                for hand_landmarks in results.multi_hand_landmarks:
                    # �����ֲ��ؼ���
                    self.mp_draw.draw_landmarks(
                        cv_image, 
                        hand_landmarks, 
                        self.mp_hands.HAND_CONNECTIONS,
                        self.drawing_spec,
                        self.drawing_spec
                    )
                    
                    gesture = self.recognize_gesture(hand_landmarks)

                    self.process_recognized_gesture(gesture, cv_image)
            else:
                self.current_status = DetectionStatus.NO_HAND
                self.reset_gesture_counts()

            if self.debug_mode:
                self.publish_debug_image(cv_image)
                
        except Exception as e:
            self.get_logger().error(f'Error processing image: {str(e)}')

    def recognize_gesture(self, hand_landmarks):
        """ʶ����������"""
        # ���ȼ���Ƿ�Ϊ����9����
        if self.detect_number_nine_gesture(hand_landmarks):
            self.recent_gestures.append(GestureType.NUMBER_NINE)
            return GestureType.NUMBER_NINE
            
        if self.detect_help_gesture(hand_landmarks):
            self.recent_gestures.append(GestureType.HELP)
            return GestureType.HELP
            
        if self.detect_ok_gesture(hand_landmarks):
            self.recent_gestures.append(GestureType.OK)
            return GestureType.OK
            
        # ���û��ʶ���ض����ƣ�����δ֪
        self.recent_gestures.append(GestureType.UNKNOWN)
        return GestureType.UNKNOWN

    def process_recognized_gesture(self, gesture, image):
        """����ʶ�𵽵�����"""
        self.gesture_counts[gesture] += 1
        
        # ���������������ͣ���������9���Ƽ���
        if gesture != GestureType.NUMBER_NINE:
            self.gesture_counts[GestureType.NUMBER_NINE] = 0
        if (gesture == GestureType.NUMBER_NINE and 
            self.gesture_counts[GestureType.NUMBER_NINE] >= self.emergency_gesture_count):
            self.trigger_emergency(image)
            self.current_status = DetectionStatus.EMERGENCY_TRIGGERED

    def detect_number_nine_gesture(self, hand_landmarks):
        """�������9����"""
        if not hand_landmarks:
            return False
        points = []
        for landmark in hand_landmarks.landmark:
            points.append((landmark.x, landmark.y, landmark.z))
        
        # �ж��Ƿ�Ϊ����9����
        thumb_up = points[4][1] < points[3][1]  # Ĵָ����
        index_bent = points[8][1] > points[6][1]  # ʳָ����
        middle_bent = points[12][1] > points[10][1]  # ��ָ����
        ring_bent = points[16][1] > points[14][1]  # ����ָ����
        pinky_bent = points[20][1] > points[18][1]  # Сָ����
        
        return thumb_up and index_bent and middle_bent and ring_bent and pinky_bent

    def detect_help_gesture(self, hand_landmarks):
        """����������"""
        if not hand_landmarks:
            return False
            
        points = []
        for landmark in hand_landmarks.landmark:
            points.append((landmark.x, landmark.y, landmark.z))
            
        all_fingers_up = (
            points[4][1] < points[3][1] and  # Ĵָ����
            points[8][1] < points[6][1] and  # ʳָ����
            points[12][1] < points[10][1] and  # ��ָ����
            points[16][1] < points[14][1] and  # ����ָ����
            points[20][1] < points[18][1]  # Сָ����
        )
        
        return all_fingers_up

    def detect_ok_gesture(self, hand_landmarks):
        """���OK����"""
        if not hand_landmarks:
            return False
            
        points = []
        for landmark in hand_landmarks.landmark:
            points.append((landmark.x, landmark.y, landmark.z))
            
        thumb_tip = points[4]
        index_tip = points[8]
        
        distance = np.sqrt(
            (thumb_tip[0] - index_tip[0])**2 + 
            (thumb_tip[1] - index_tip[1])**2 + 
            (thumb_tip[2] - index_tip[2])**2
        )
        
        return distance < 0.1

    def trigger_emergency(self, image):
        """�����������"""
        current_time = time.time()

        if current_time - self.last_emergency_time < self.emergency_cooldown:
            return
            
        self.last_emergency_time = current_time
        
        emergency_msg = String()
        emergency_msg.data = json.dumps({
            'timestamp': current_time,
            'message': 'Emergency gesture detected!',
            'gesture': 'NUMBER_NINE',
            'confidence': self.gesture_counts[GestureType.NUMBER_NINE] / self.emergency_gesture_count
        })
        
        self.emergency_publisher.publish(emergency_msg)
        self.get_logger().warn('Emergency gesture detected! Alert sent.')
        
        self.reset_gesture_counts()

    def reset_gesture_counts(self):
        """�������Ƽ���"""
        for gesture in GestureType:
            self.gesture_counts[gesture] = 0

    def publish_debug_image(self, image):
        """��������ͼ��"""
        try:
            status_text = f"Status: {self.current_status.name}"
            cv2.putText(
                image, 
                status_text, 
                (10, 30), 
                cv2.FONT_HERSHEY_SIMPLEX, 
                1, 
                (0, 0, 255), 
                2
            )

            gesture_text = f"9 Gesture Count: {self.gesture_counts[GestureType.NUMBER_NINE]}/{self.emergency_gesture_count}"
            cv2.putText(
                image, 
                gesture_text, 
                (10, 70), 
                cv2.FONT_HERSHEY_SIMPLEX, 
                1, 
                (0, 255, 0), 
                2
            )
            debug_img_msg = self.bridge.cv2_to_imgmsg(image, encoding="bgr8")
            self.debug_image_publisher.publish(debug_img_msg)
            
        except Exception as e:
            self.get_logger().error(f'Error publishing debug image: {str(e)}')

def main(args=None):
    rclpy.init(args=args)
    node = GestureRecognitionNode()
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info('Node stopped cleanly')
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
