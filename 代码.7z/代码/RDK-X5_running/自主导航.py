import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan, Image
from geometry_msgs.msg import Twist, PoseStamped, PoseWithCovarianceStamped
from nav_msgs.msg import OccupancyGrid, Path, Odometry
from nav_msgs.srv import GetMap
from std_msgs.msg import String, Float32MultiArray
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy, DurabilityPolicy
from cv_bridge import CvBridge
import numpy as np
import cv2
import math
import time
import threading
import json
from enum import Enum
import heapq
import websockets
import asyncio
from rclpy.callback_groups import ReentrantCallbackGroup
from rclpy.executors import MultiThreadedExecutor
from tf2_ros import TransformBroadcaster, TransformListener, Buffer
from geometry_msgs.msg import TransformStamped

class NavigationState(Enum):
    IDLE = 0
    EXPLORING = 1
    NAVIGATING = 2
    OBSTACLE_AVOIDING = 3
    GOAL_REACHED = 4
    ERROR = 5

class MapCell(Enum):
    UNKNOWN = -1
    FREE = 0
    OCCUPIED = 100
    TEMP_OBSTACLE = 50

class NavigationSystem(Node):
    def __init__(self):
        super().__init__('navigation_system')
        
        # ��ʼ����ģ��
        self.setup_parameters()
        self.setup_publishers_subscribers()
        self.setup_tf()
        self.initialize_map()
        self.setup_web_server()
        
        # ������ͼ���º�·���滮�߳�
        self.create_timers()
        
        self.get_logger().info('����ϵͳ�ѳ�ʼ�����')

    def setup_parameters(self):
        """����ϵͳ����"""
        # ��������
        self.state = NavigationState.IDLE
        self.obstacle_distance = 0.5  # �ϰ����������ֵ(��)
        self.forward_speed = 0.2      # ǰ���ٶ�(��/��)
        self.rotation_speed = 0.5     # ��ת�ٶ�(����/��)
        self.goal_tolerance = 0.2     # Ŀ�����ݲ�(��)
        self.recovery_mode = False    # �ָ�ģʽ��־
        
        # ��ͼ����
        self.map_resolution = 0.05    # ��ͼ�ֱ���(��/����)
        self.map_width = 1000         # ��ͼ����(����)
        self.map_height = 1000        # ��ͼ�߶�(����)
        self.map_origin_x = -25.0     # ��ͼԭ��X����
        self.map_origin_y = -25.0     # ��ͼԭ��Y����
        self.map_data = np.ones((self.map_height, self.map_width), dtype=np.int8) * -1 
        
        # ɨ�����
        self.front_angles = (-np.pi/6, np.pi/6)               # ǰ��ɨ������
        self.left_front_angles = (np.pi/6, np.pi/3)           # ��ǰ��ɨ������
        self.right_front_angles = (-np.pi/3, -np.pi/6)        # ��ǰ��ɨ������
        self.scan_regions = {
            'front': self.front_angles,
            'left_front': self.left_front_angles,
            'right_front': self.right_front_angles,
            'left': (np.pi/3, 2*np.pi/3),
            'right': (-2*np.pi/3, -np.pi/3),
            'rear': (2*np.pi/3, -2*np.pi/3)
        }
        
        self.robot_pose = {'x': 0.0, 'y': 0.0, 'theta': 0.0}
        self.path = []
        self.current_goal = None
        self.path_index = 0
        self.bridge = CvBridge()
        self.last_scan = None
        self.last_odom_time = time.time()
        self.is_mapping = False
        self.slam_initialized = False
        self.movement_history = []
        
    def setup_publishers_subscribers(self):
        """���÷����ߺͶ�����"""
        map_qos = QoSProfile(
            reliability=ReliabilityPolicy.RELIABLE,
            durability=DurabilityPolicy.TRANSIENT_LOCAL,
            history=HistoryPolicy.KEEP_LAST,
            depth=1
        )
        
        sensor_qos = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            history=HistoryPolicy.KEEP_LAST,
            depth=10
        )
        
        self.callback_group = ReentrantCallbackGroup()
        self.scan_sub = self.create_subscription(
            LaserScan,
            'scan',
            self.scan_callback,
            sensor_qos,
            callback_group=self.callback_group
        )
        
        self.odom_sub = self.create_subscription(
            Odometry,
            'odom',
            self.odom_callback,
            10,
            callback_group=self.callback_group
        )
        
        self.camera_sub = self.create_subscription(
            Image,
            'camera/image_raw',
            self.camera_callback,
            sensor_qos,
            callback_group=self.callback_group
        )
        
        self.goal_sub = self.create_subscription(
            PoseStamped,
            'goal_pose',
            self.goal_callback,
            10,
            callback_group=self.callback_group
        )
        
        self.amcl_pose_sub = self.create_subscription(
            PoseWithCovarianceStamped,
            'amcl_pose',
            self.amcl_pose_callback,
            10,
            callback_group=self.callback_group
        )

        self.cmd_vel_pub = self.create_publisher(
            Twist,
            'cmd_vel',
            10
        )
        
        self.map_pub = self.create_publisher(
            OccupancyGrid,
            'map',
            map_qos
        )
        
        self.path_pub = self.create_publisher(
            Path,
            'planned_path',
            10
        )
        
        self.status_pub = self.create_publisher(
            String,
            'navigation_status',
            10
        )
        
        self.visualization_pub = self.create_publisher(
            Image,
            'navigation_visualization',
            10
        )
        
    def setup_tf(self):
        self.tf_broadcaster = TransformBroadcaster(self)
        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)
        
    def initialize_map(self):
        """��ʼ����ͼ"""
        self.occupancy_grid = OccupancyGrid()
        self.occupancy_grid.header.frame_id = 'map'
        self.occupancy_grid.info.resolution = self.map_resolution
        self.occupancy_grid.info.width = self.map_width
        self.occupancy_grid.info.height = self.map_height
        self.occupancy_grid.info.origin.position.x = self.map_origin_x
        self.occupancy_grid.info.origin.position.y = self.map_origin_y
        self.occupancy_grid.data = list(np.reshape(self.map_data, -1).astype(np.int8))
        
        # ������ʼ��ͼ
        self.publish_map()
    
    def setup_web_server(self):
        self.clients = set()
        self.web_server_thread = threading.Thread(target=self.run_web_server)
        self.web_server_thread.daemon = True
        self.web_server_thread.start()
        
    def create_timers(self):
        self.map_update_timer = self.create_timer(1.0, self.update_map)
        self.pose_pub_timer = self.create_timer(0.1, self.publish_robot_pose)
        self.path_planning_timer = self.create_timer(0.5, self.path_planning)
        self.web_update_timer = self.create_timer(0.2, self.update_web_clients)
    
    def scan_callback(self, msg):
        """���������״�����"""
        try:
            self.last_scan = msg
            ranges = np.array(msg.ranges)
            max_range = msg.range_max
            ranges = np.where(np.isfinite(ranges), ranges, max_range)

            angle_min = msg.angle_min
            angle_increment = msg.angle_increment
            angles = np.array([angle_min + i * angle_increment for i in range(len(ranges))])
 
            obstacles = {}
            for region_name, angle_range in self.scan_regions.items():
                obstacles[region_name] = self.check_obstacle_in_range(ranges, angles, angle_range)
            if self.is_mapping:
                self.update_map_from_scan(ranges, angles)
            
            # ���ϵ����߼�
            if self.state == NavigationState.NAVIGATING or self.state == NavigationState.EXPLORING:
                self.obstacle_avoidance(obstacles, ranges, angles)
            
        except Exception as e:
            self.get_logger().error(f'�����״����ݴ�������: {str(e)}')
    
    def camera_callback(self, msg):
        try:
            cv_image = self.bridge.imgmsg_to_cv2(msg, "bgr8")
            
            processed_image = self.process_image(cv_image)
            
            self.visualize_navigation(processed_image)
            
        except Exception as e:
            self.get_logger().error(f'������ݴ�������: {str(e)}')
    
    def odom_callback(self, msg):
        """������̼�����"""
        try:
            position = msg.pose.pose.position
            orientation = msg.pose.pose.orientation
            
            siny_cosp = 2 * (orientation.w * orientation.z + orientation.x * orientation.y)
            cosy_cosp = 1 - 2 * (orientation.y * orientation.y + orientation.z * orientation.z)
            theta = math.atan2(siny_cosp, cosy_cosp)
            self.robot_pose['x'] = position.x
            self.robot_pose['y'] = position.y
            self.robot_pose['theta'] = theta
            
            # ��¼�ƶ���ʷ
            current_time = time.time()
            if current_time - self.last_odom_time > 0.5: 
                self.movement_history.append((position.x, position.y))
                if len(self.movement_history) > 100:  # ��ౣ��100����
                    self.movement_history.pop(0)
                self.last_odom_time = current_time
            
            # ����TF�任
            self.publish_tf_transform()
            
        except Exception as e:
            self.get_logger().error(f'��̼����ݴ�������: {str(e)}')
    
    def amcl_pose_callback(self, msg):
        """����AMCLλ������"""
        try:
            # ���»�����ȫ��λ��
            position = msg.pose.pose.position
            orientation = msg.pose.pose.orientation
            
            # ����SLAM״̬
            self.slam_initialized = True
            
        except Exception as e:
            self.get_logger().error(f'AMCLλ�˴�������: {str(e)}')
    
    def goal_callback(self, msg):
        """��������Ŀ��"""
        try:
            self.current_goal = {
                'x': msg.pose.position.x,
                'y': msg.pose.position.y
            }
            self.get_logger().info(f'�յ��µ���Ŀ��: ({self.current_goal["x"]:.2f}, {self.current_goal["y"]:.2f})')

            self.state = NavigationState.NAVIGATING
            self.path_index = 0
            self.path = []  # �����·��
            
            self.publish_status(f"��ʼ������Ŀ��� ({self.current_goal['x']:.2f}, {self.current_goal['y']:.2f})")
            
        except Exception as e:
            self.get_logger().error(f'Ŀ�괦������: {str(e)}')
    
    def check_obstacle_in_range(self, ranges, angles, angle_range):
        """���ָ���Ƕȷ�Χ���Ƿ����ϰ���"""
        min_angle, max_angle = angle_range
        
        # ������Խ -�� �� �� �߽�����
        if min_angle > max_angle:
            mask = (angles >= min_angle) | (angles <= max_angle)
        else:
            mask = (angles >= min_angle) & (angles <= max_angle)
            
        range_in_sector = ranges[mask]
        
        # �ж��Ƿ��в���ֵС����ֵ
        if len(range_in_sector) == 0:
            return False
        
        min_distance = np.min(range_in_sector)
        return min_distance < self.obstacle_distance, min_distance
    
    def update_map_from_scan(self, ranges, angles):
        """���ݼ����״����ݸ��µ�ͼ"""
        if not self.slam_initialized:
            return

        robot_map_x, robot_map_y = self.world_to_map(self.robot_pose['x'], self.robot_pose['y'])

        for i, (r, angle) in enumerate(zip(ranges, angles)):
            if r >= self.last_scan.range_max:  # �������Χ�ĵ�
                continue
   
            global_angle = self.robot_pose['theta'] + angle
            point_x = self.robot_pose['x'] + r * math.cos(global_angle)
            point_y = self.robot_pose['y'] + r * math.sin(global_angle)
            
            map_x, map_y = self.world_to_map(point_x, point_y)

            if 0 <= map_x < self.map_width and 0 <= map_y < self.map_height:
                self.map_data[map_y, map_x] = MapCell.OCCUPIED.value
                
            self.mark_free_space(robot_map_x, robot_map_y, map_x, map_y)
    
    def world_to_map(self, world_x, world_y):
        map_x = int((world_x - self.map_origin_x) / self.map_resolution)
        map_y = int((world_y - self.map_origin_y) / self.map_resolution)
        return map_x, map_y
    
    def map_to_world(self, map_x, map_y):
        world_x = map_x * self.map_resolution + self.map_origin_x
        world_y = map_y * self.map_resolution + self.map_origin_y
        return world_x, world_y
    
    def mark_free_space(self, x0, y0, x1, y1):
        dx = abs(x1 - x0)
        dy = abs(y1 - y0)
        sx = 1 if x0 < x1 else -1
        sy = 1 if y0 < y1 else -1
        err = dx - dy
        
        while True:
            if 0 <= x0 < self.map_width and 0 <= y0 < self.map_height:
                if self.map_data[y0, x0] != MapCell.OCCUPIED.value:
                    self.map_data[y0, x0] = MapCell.FREE.value
            if x0 == x1 and y0 == y1:
                break
                
            e2 = 2 * err
            if e2 > -dy:
                err -= dy
                x0 += sx
            if e2 < dx:
                err += dx
                y0 += sy
    
    def update_map(self):
        if self.is_mapping:
            self.publish_map()
    
    def publish_map(self):
        self.occupancy_grid.header.stamp = self.get_clock().now().to_msg()
        self.occupancy_grid.data = list(np.reshape(self.map_data, -1).astype(np.int8))
        self.map_pub.publish(self.occupancy_grid)
    
    def obstacle_avoidance(self, obstacles, ranges, angles):
        cmd = Twist()
        
        # ���ǰ���Ƿ����ϰ���
        is_front_obstacle, front_dist = obstacles['front']
        is_left_front_obstacle, _ = obstacles['left_front']
        is_right_front_obstacle, _ = obstacles['right_front']
        
        if is_front_obstacle:
            # ǰ�����ϰ����Ҫ����
            self.state = NavigationState.OBSTACLE_AVOIDING
            self.get_logger().info(f'ǰ��{front_dist:.2f}�״���⵽�ϰ����ʼ����')
            
            cmd.linear.x = 0.0  # ֹͣǰ��
            
            # ����ת����
            if is_left_front_obstacle and not is_right_front_obstacle:
                cmd.angular.z = -self.rotation_speed
                self.get_logger().info('����ת')
            elif not is_left_front_obstacle and is_right_front_obstacle:
                cmd.angular.z = self.rotation_speed
                self.get_logger().info('����ת')
            else:
                # ������ѱ��Ϸ���
                free_direction = self.calculate_free_direction(ranges, angles)
                cmd.angular.z = 0.5 * (free_direction - self.robot_pose['theta'])
                self.get_logger().info(f'��ת����ѷ���: {math.degrees(free_direction):.1f}��')
        
        elif self.state == NavigationState.NAVIGATING and self.path:
            # �ع滮·������
            self.follow_path(cmd)
        
        elif self.state == NavigationState.EXPLORING:
            free_direction = self.calculate_free_direction(ranges, angles)
            angle_diff = free_direction - self.robot_pose['theta']
            while angle_diff > math.pi:
                angle_diff -= 2*math.pi
            while angle_diff < -math.pi:
                angle_diff += 2*math.pi
                
            if abs(angle_diff) > 0.3: 
                cmd.linear.x = 0.0
                cmd.angular.z = 0.3 * angle_diff
            else:
                cmd.linear.x = self.forward_speed
                cmd.angular.z = 0.1 * angle_diff  
        
        else:
            # Ĭ����Ϊ��ֱ��
            cmd.linear.x = self.forward_speed
            cmd.angular.z = 0.0
        
        self.cmd_vel_pub.publish(cmd)
    
    def calculate_free_direction(self, ranges, angles):

        weights = np.array(ranges) ** 2  

        normalized_angles = angles.copy()
        for i in range(len(normalized_angles)):
            while normalized_angles[i] > math.pi:
                normalized_angles[i] -= 2*math.pi
            while normalized_angles[i] < -math.pi:
                normalized_angles[i] += 2*math.pi
        
        sin_sum = np.sum(np.sin(normalized_angles) * weights)
        cos_sum = np.sum(np.cos(normalized_angles) * weights)
        
        direction = math.atan2(sin_sum, cos_sum)
        return direction
    
    def path_planning(self):
        """·���滮"""
        if self.state != NavigationState.NAVIGATING or self.current_goal is None:
            return
            
        if not self.path:
            # ��Ҫ�滮��·��
            start = self.world_to_map(self.robot_pose['x'], self.robot_pose['y'])
            goal = self.world_to_map(self.current_goal['x'], self.current_goal['y'])
            if not self.is_valid_point(goal[0], goal[1]):
                self.get_logger().warn('Ŀ��㲻�ɴ�����ϰ�����')
                self.state = NavigationState.ERROR
                self.publish_status("��������Ŀ��㲻�ɴ�")
                return
                
            # ʹ��A*�㷨�滮·��
            self.get_logger().info('��ʼ·���滮...')
            path = self.a_star_path_planning(start, goal)
            
            if path:
                self.path = [self.map_to_world(x, y) for x, y in path]
                self.get_logger().info(f'�滮·������ {len(self.path)} ����')
                self.publish_path()
            else:
                self.get_logger().warn('�޷��ҵ�·��')
                self.state = NavigationState.ERROR
                self.publish_status("���������޷��ҵ�·��")
    
    def a_star_path_planning(self, start, goal):
        """A*·���滮�㷨"""
        def heuristic(a, b):
            return math.sqrt((a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2)
 
        def get_neighbors(node):
            x, y = node
            neighbors = []
            for dx, dy in [(0, 1), (1, 0), (0, -1), (-1, 0), (1, 1), (-1, 1), (1, -1), (-1, -1)]:
                nx, ny = x + dx, y + dy
                if self.is_valid_point(nx, ny):
                    if abs(dx) + abs(dy) == 2: 
                        if self.is_valid_point(x + dx, y) and self.is_valid_point(x, y + dy):
                            neighbors.append((nx, ny))
                    else:
                        neighbors.append((nx, ny))
            return neighbors
        
        # A*�㷨ʵ��
        open_set = []
        heapq.heappush(open_set, (0, start))
        came_from = {}
        g_score = {start: 0}
        f_score = {start: heuristic(start, goal)}
        open_set_hash = {start}
        
        while open_set:
            current = heapq.heappop(open_set)[1]
            open_set_hash.remove(current)
            
            if current == goal:
                path = []
                while current in came_from:
                    path.append(current)
                    current = came_from[current]
                path.append(start)
                path.reverse()
                return path
                
            for neighbor in get_neighbors(current):
                if abs(neighbor[0] - current[0]) + abs(neighbor[1] - current[1]) == 2:
                    tentative_g_score = g_score[current] + 1.414
                else:
                    tentative_g_score = g_score[current] + 1
                    
                if neighbor not in g_score or tentative_g_score < g_score[neighbor]:
                    came_from[neighbor] = current
                    g_score[neighbor] = tentative_g_score
                    f_score[neighbor] = tentative_g_score + heuristic(neighbor, goal)
                    if neighbor not in open_set_hash:
                        heapq.heappush(open_set, (f_score[neighbor], neighbor))
                        open_set_hash.add(neighbor)
        
        return None 
    
    def is_valid_point(self, x, y):
        if 0 <= x < self.map_width and 0 <= y < self.map_height:
            return self.map_data[y, x] != MapCell.OCCUPIED.value
        return False
    
    def follow_path(self, cmd):
        if not self.path or self.path_index >= len(self.path):
            return
            
        target = self.path[self.path_index]
        target_x, target_y = target
        
        dx = target_x - self.robot_pose['x']
        dy = target_y - self.robot_pose['y']
        distance = math.sqrt(dx*dx + dy*dy)
        
        if distance < self.goal_tolerance:
            self.path_index += 1
            
            if self.path_index >= len(self.path):
                self.get_logger().info('����Ŀ���')
                self.state = NavigationState.GOAL_REACHED
                self.publish_status("������ɣ�����Ŀ���")
                cmd.linear.x = 0.0
                cmd.angular.z = 0.0
                return
                
            return  
        
        target_angle = math.atan2(dy, dx)
        
        angle_diff = target_angle - self.robot_pose['theta']
        
        while angle_diff > math.pi:
            angle_diff -= 2*math.pi
        while angle_diff < -math.pi:
            angle_diff += 2*math.pi
            
        if abs(angle_diff) > 0.3:
            cmd.linear.x = 0.0
            cmd.angular.z = 0.5 * angle_diff  
        else:
            cmd.linear.x = 0.15 
            cmd.angular.z = 0.3 * angle_diff
    
    def publish_path(self):
        path_msg = Path()
        path_msg.header.frame_id = 'map'
        path_msg.header.stamp = self.get_clock().now().to_msg()
        
        for x, y in self.path:
            pose = PoseStamped()
            pose.header = path_msg.header
            pose.pose.position.x = x
            pose.pose.position.y = y
            pose.pose.position.z = 0.0
            pose.pose.orientation.w = 1.0
            path_msg.poses.append(pose)
        
        self.path_pub.publish(path_msg)
    
    def publish_status(self, status_msg):
        msg = String()
        msg.data = status_msg
        self.status_pub.publish(msg)
        self.get_logger().info(status_msg)
    
    def publish_robot_pose(self):
        self.publish_tf_transform()
    
    def publish_tf_transform(self):
        t = TransformStamped()
    
        t.header.stamp = self.get_clock().now().to_msg()
        t.header.frame_id = 'map'
        t.child_frame_id = 'base_link'
        
        t.transform.translation.x = self.robot_pose['x']
        t.transform.translation.y = self.robot_pose['y']
        t.transform.translation.z = 0.0
        
        cy = math.cos(self.robot_pose['theta'] * 0.5)
        sy = math.sin(self.robot_pose['theta'] * 0.5)
        t.transform.rotation.x = 0.0
        t.transform.rotation.y = 0.0
        t.transform.rotation.z = sy
        t.transform.rotation.w = cy
        
        self.tf_broadcaster.sendTransform(t)
    
    def process_image(self, image):

        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        blurred = cv2.GaussianBlur(gray, (5, 5), 0)
        edges = cv2.Canny(blurred, 50, 150)

        edges_color = cv2.cvtColor(edges, cv2.COLOR_GRAY2BGR)
        
        return edges_color
    
    def visualize_navigation(self, image):
        try:

            vis_img = np.zeros((480, 640, 3), dtype=np.uint8)
            map_size = 200
            map_img = np.zeros((map_size, map_size, 3), dtype=np.uint8)

            robot_map_x, robot_map_y = self.world_to_map(self.robot_pose['x'], self.robot_pose['y'])

            x_min = max(0, robot_map_x - map_size//2)
            y_min = max(0, robot_map_y - map_size//2)
            x_max = min(self.map_width, x_min + map_size)
            y_max = min(self.map_height, y_min + map_size)

            actual_width = x_max - x_min
            actual_height = y_max - y_min

            for y in range(actual_height):
                for x in range(actual_width):
                    map_val = self.map_data[y_min + y, x_min + x]
                    if map_val == MapCell.OCCUPIED.value:
                        map_img[y, x] = [0, 0, 255]  # ��ɫ��ʾ�ϰ���
                    elif map_val == MapCell.FREE.value:
                        map_img[y, x] = [255, 255, 255]  # ��ɫ��ʾ��������
                    else:
                        map_img[y, x] = [128, 128, 128]  # ��ɫ��ʾδ֪����
            
            robot_x = robot_map_x - x_min
            robot_y = robot_map_y - y_min
            if 0 <= robot_x < actual_width and 0 <= robot_y < actual_height:
                cv2.circle(map_img, (robot_x, robot_y), 3, (0, 255, 0), -1)

                direction_length = 10
                end_x = int(robot_x + direction_length * math.cos(self.robot_pose['theta']))
                end_y = int(robot_y + direction_length * math.sin(self.robot_pose['theta']))
                cv2.line(map_img, (robot_x, robot_y), (end_x, end_y), (0, 255, 0), 2)

            if self.path:
                for i in range(len(self.path)-1):
                    x1, y1 = self.world_to_map(self.path[i][0], self.path[i][1])
                    x2, y2 = self.world_to_map(self.path[i+1][0], self.path[i+1][1])

                    x1 -= x_min
                    y1 -= y_min
                    x2 -= x_min
                    y2 -= y_min
                    
                    if (0 <= x1 < actual_width and 0 <= y1 < actual_height and
                        0 <= x2 < actual_width and 0 <= y2 < actual_height):
                        cv2.line(map_img, (x1, y1), (x2, y2), (255, 0, 0), 1)

            vis_img[10:10+actual_height, 10:10+actual_width] = map_img[:actual_height, :actual_width]
            

            cv2.putText(
                vis_img, 
                f"״̬: {self.state.name}", 
                (10, 30 + actual_height), 
                cv2.FONT_HERSHEY_SIMPLEX, 
                0.5, 
                (255, 255, 255), 
                1
            )
            
            if self.current_goal:
                cv2.putText(
                    vis_img, 
                    f"Ŀ��: ({self.current_goal['x']:.2f}, {self.current_goal['y']:.2f})", 
                    (10, 50 + actual_height), 
                    cv2.FONT_HERSHEY_SIMPLEX, 
                    0.5, 
                    (255, 255, 255), 
                    1
                )
            
            cv2.putText(
                vis_img, 
                f"λ��: ({self.robot_pose['x']:.2f}, {self.robot_pose['y']:.2f}, {math.degrees(self.robot_pose['theta']):.1f}��)", 
                (10, 70 + actual_height), 
                cv2.FONT_HERSHEY_SIMPLEX, 
                0.5, 
                (255, 255, 255), 
                1
            )
            
            # �������ӻ�ͼ��
            vis_msg = self.bridge.cv2_to_imgmsg(vis_img, encoding="bgr8")
            self.visualization_pub.publish(vis_msg)
            
        except Exception as e:
            self.get_logger().error(f'���ӻ���������: {str(e)}')
    
    async def handle_websocket(self, websocket, path):
        try:
            self.clients.add(websocket)
            self.get_logger().info(f'Web�ͻ���������: {websocket.remote_address}')
            
            async for message in websocket:
                try:
                    data = json.loads(message)
                    cmd = data.get('cmd')
                    
                    if cmd == 'set_goal':
                        x = float(data.get('x', 0))
                        y = float(data.get('y', 0))
                        
                        goal_msg = PoseStamped()
                        goal_msg.header.frame_id = 'map'
                        goal_msg.header.stamp = self.get_clock().now().to_msg()
                        goal_msg.pose.position.x = x
                        goal_msg.pose.position.y = y
                        goal_msg.pose.orientation.w = 1.0
                        
                        self.goal_callback(goal_msg)
                        
                    elif cmd == 'start_mapping':
                        # ������ͼ
                        self.is_mapping = True
                        self.state = NavigationState.EXPLORING
                        self.publish_status("��ʼ��ͼģʽ")
                        
                    elif cmd == 'stop_mapping':
                        # ֹͣ��ͼ
                        self.is_mapping = False
                        self.state = NavigationState.IDLE
                        self.publish_status("ֹͣ��ͼģʽ")
                        
                    elif cmd == 'save_map':
                        # �����ͼ
                        try:
                            import pickle
                            with open(data.get('filename', 'map.pkl'), 'wb') as f:
                                pickle.dump({
                                    'data': self.map_data,
                                    'resolution': self.map_resolution,
                                    'origin_x': self.map_origin_x,
                                    'origin_y': self.map_origin_y,
                                    'width': self.map_width,
                                    'height': self.map_height
                                }, f)
                            await websocket.send(json.dumps({'status': 'success', 'message': '��ͼ����ɹ�'}))
                        except Exception as e:
                            await websocket.send(json.dumps({'status': 'error', 'message': f'��ͼ����ʧ��: {str(e)}'}))
                        
                    elif cmd == 'load_map':
                        try:
                            import pickle
                            with open(data.get('filename', 'map.pkl'), 'rb') as f:
                                map_data = pickle.load(f)
                                self.map_data = map_data['data']
                                self.map_resolution = map_data['resolution']
                                self.map_origin_x = map_data['origin_x']
                                self.map_origin_y = map_data['origin_y']
                                self.map_width = map_data['width']
                                self.map_height = map_data['height']
   
                                self.initialize_map()
                                
                            await websocket.send(json.dumps({'status': 'success', 'message': '��ͼ���سɹ�'}))
                        except Exception as e:
                            await websocket.send(json.dumps({'status': 'error', 'message': f'��ͼ����ʧ��: {str(e)}'}))
                    
                    elif cmd == 'emergency_stop':
                        # ����ֹͣ
                        stop_cmd = Twist()
                        self.cmd_vel_pub.publish(stop_cmd)
                        self.state = NavigationState.IDLE
                        self.publish_status("����ֹͣ")
                        
                except json.JSONDecodeError:
                    self.get_logger().warn(f'�յ���ЧJSON��Ϣ: {message}')
                except Exception as e:
                    self.get_logger().error(f'������Ϣ����: {str(e)}')
        
        except websockets.exceptions.ConnectionClosed:
            pass
        finally:
            self.clients.remove(websocket)
            self.get_logger().info(f'Web�ͻ����ѶϿ�����: {websocket.remote_address}')
    
    def run_web_server(self):
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        
        start_server = websockets.serve(
            self.handle_websocket, 
            host='0.0.0.0', 
            port=9090
        )
        
        self.get_logger().info('WebSocket�������������� ws://0.0.0.0:9090')
        
        loop.run_until_complete(start_server)
        loop.run_forever()
    
    def update_web_clients(self):
        if not self.clients:
            return
            
        try:
            data = {
                'robot_pose': self.robot_pose,
                'state': self.state.name,
                'path': self.path if self.path else [],
                'goal': self.current_goal,
                'timestamp': time.time()
            }
            
            json_str = json.dumps(data)
            
            asyncio.run_coroutine_threadsafe(
                self.send_to_all_clients(json_str),
                asyncio.get_event_loop()
            )
            
        except Exception as e:
            self.get_logger().error(f'Web�ͻ��˸��´���: {str(e)}')
    
    async def send_to_all_clients(self, message):
        if not self.clients:
            return
            
        disconnected = set()
        for websocket in self.clients:
            try:
                await websocket.send(message)
            except websockets.exceptions.ConnectionClosed:
                disconnected.add(websocket)

        self.clients -= disconnected

def main(args=None):
    rclpy.init(args=args)

    navigation_system = NavigationSystem()
    
    executor = MultiThreadedExecutor()
    executor.add_node(navigation_system)
    
    try:
        executor.spin()
    except KeyboardInterrupt:
        pass
    finally:
        # ����ֹͣ����
        stop_cmd = Twist()
        navigation_system.cmd_vel_pub.publish(stop_cmd)
        navigation_system.get_logger().info('�ڵ�رգ���������ֹͣ')
        executor.shutdown()
        navigation_system.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
